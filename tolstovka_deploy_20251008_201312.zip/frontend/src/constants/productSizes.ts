export const PRODUCT_SIZE_OPTIONS = [
  { value: '', label: 'Без размера' },
  { value: 'XXS', label: 'XXS' },
  { value: 'XS', label: 'XS' },
  { value: 'S', label: 'S' },
  { value: 'M', label: 'M' },
  { value: 'L', label: 'L' },
  { value: 'XL', label: 'XL' },
  { value: 'XXL', label: 'XXL' },
  { value: 'XXXL', label: 'XXXL' },
  { value: 'ONE SIZE', label: 'One Size' }
]


const normalized = (value: string) => value.replace(/\s+/g, '').toUpperCase()

export const PRODUCT_SIZE_LABEL_MAP = new Map<string, string>(
  PRODUCT_SIZE_OPTIONS.map(option => [
    normalized(option.value),
    option.label
  ])
)

export function formatProductSizeLabel(value?: string | null): string {
  if (!value) {
    return PRODUCT_SIZE_OPTIONS[0]?.label || 'Без размера'
  }
  const label = PRODUCT_SIZE_LABEL_MAP.get(normalized(value))
  return label ?? value
}

export const PRODUCT_SIZE_ORDER = PRODUCT_SIZE_OPTIONS
  .map(option => normalized(option.value))
  .filter(Boolean)
