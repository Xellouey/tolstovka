import { defineStore } from 'pinia'
import { ref, computed, watch } from 'vue'
import { $fetch } from '@/utils/http'
import type { Product } from './catalog'

export interface CartItem {
  product: Product
  quantity: number
}

export interface PromoDetails {
  description: string
  discountType: 'percent' | 'fixed'
  discountValue: number
  minSubtotal: number
  maxUses: number | null
  usageCount: number
  remainingUses: number | null
  isActive: boolean
  expiresAt: string | null
  lastUsedAt?: string | null
  createdAt?: string
  updatedAt?: string
}

export interface AppliedPromo {
  code: string
  discount: number
  newTotal: number
  promo: PromoDetails
}

const STORAGE_KEY = 'tolstovka-cart'
const PROMO_STORAGE_KEY = 'tolstovka-cart-promo'

function loadCart(): CartItem[] {
  if (typeof window === 'undefined') {
    return []
  }

  try {
    const stored = window.localStorage.getItem(STORAGE_KEY)
    if (stored) {
      return JSON.parse(stored) as CartItem[]
    }
  } catch (error) {
    console.error('Failed to load cart from localStorage:', error)
  }
  return []
}

function saveCart(items: CartItem[]) {
  if (typeof window === 'undefined') {
    return
  }

  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  } catch (error) {
    console.error('Failed to save cart to localStorage:', error)
  }
}

function loadStoredPromoCode(): string | null {
  if (typeof window === 'undefined') {
    return null
  }

  try {
    const stored = window.localStorage.getItem(PROMO_STORAGE_KEY)
    if (!stored) return null
    const parsed = JSON.parse(stored)
    if (parsed && typeof parsed.code === 'string') {
      return parsed.code as string
    }
  } catch (error) {
    console.warn('Failed to load promo code from storage:', error)
  }
  return null
}

function savePromoCode(code: string | null) {
  if (typeof window === 'undefined') {
    return
  }

  try {
    if (!code) {
      window.localStorage.removeItem(PROMO_STORAGE_KEY)
    } else {
      window.localStorage.setItem(PROMO_STORAGE_KEY, JSON.stringify({ code }))
    }
  } catch (error) {
    console.warn('Failed to persist promo code:', error)
  }
}

export const useCartStore = defineStore('cart', () => {
  const items = ref<CartItem[]>(loadCart())
  const appliedPromo = ref<AppliedPromo | null>(null)
  const isApplyingPromo = ref(false)

  const itemsCount = computed(() => items.value.reduce((sum, item) => sum + item.quantity, 0))

  const totalPrice = computed(() => {
    return items.value.reduce((sum, item) => sum + item.product.priceRub * item.quantity, 0)
  })

  const isEmpty = computed(() => items.value.length === 0)

  const discountAmount = computed(() => appliedPromo.value?.discount ?? 0)
  const totalAfterDiscount = computed(() => appliedPromo.value?.newTotal ?? totalPrice.value)
  const hasPromo = computed(() => Boolean(appliedPromo.value))

  function persistCart() {
    saveCart(items.value)
  }

  function removePromo() {
    appliedPromo.value = null
    savePromoCode(null)
  }

  async function applyPromoCode(code: string, options: { silent?: boolean } = {}) {
    const normalized = code?.trim().toUpperCase()
    if (!normalized) {
      const err: any = new Error('code_required')
      err.code = 'code_required'
      throw err
    }

    if (totalPrice.value <= 0) {
      const err: any = new Error('empty_cart')
      err.code = 'empty_cart'
      throw err
    }

    try {
      isApplyingPromo.value = true
      const response = await $fetch<{ code: string; discount: number; total: number; newTotal: number; promo: PromoDetails }>(
        '/api/promocodes/apply',
        {
          method: 'POST',
          body: {
            code: normalized,
            amount: totalPrice.value
          }
        }
      )

      appliedPromo.value = {
        code: response.code,
        discount: response.discount,
        newTotal: response.newTotal,
        promo: response.promo
      }

      savePromoCode(normalized)
      return appliedPromo.value
    } catch (error) {
      if (!options.silent) {
        throw error
      }
      throw error
    } finally {
      isApplyingPromo.value = false
    }
  }

  async function refreshPromo(options: { silent?: boolean } = {}) {
    if (!appliedPromo.value) return null
    try {
      return await applyPromoCode(appliedPromo.value.code, options)
    } catch (error) {
      if (!options.silent) {
        throw error
      }
      removePromo()
      return null
    }
  }

  async function redeemPromo(metadata?: Record<string, any>) {
    if (!appliedPromo.value) {
      return null
    }

    try {
      const response = await $fetch<{
        ok: boolean
        code: string
        usageId: string
        discount: number
        total: number
        newTotal: number
        promo: PromoDetails
      }>('/api/promocodes/redeem', {
        method: 'POST',
        body: {
          code: appliedPromo.value.code,
          cartTotal: totalPrice.value,
          metadata
        }
      })

      appliedPromo.value = {
        code: response.code,
        discount: response.discount,
        newTotal: response.newTotal,
        promo: response.promo
      }

      savePromoCode(response.code)
      return response
    } catch (error) {
      console.error('[cart] Failed to redeem promo code', error)
      throw error
    }
  }

  function addToCart(product: Product) {
    const existingItem = items.value.find(item => item.product.id === product.id)

    if (existingItem) {
      existingItem.quantity++
    } else {
      items.value.push({ product, quantity: 1 })
    }

    persistCart()

    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      window.Telegram.WebApp.HapticFeedback.impactOccurred('light')
    }
  }

  function removeFromCart(productId: string | number) {
    const index = items.value.findIndex(item => item.product.id === productId)
    if (index !== -1) {
      items.value.splice(index, 1)
    }

    persistCart()

    if (!items.value.length) {
      removePromo()
    }

    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      window.Telegram.WebApp.HapticFeedback.impactOccurred('light')
    }
  }

  function updateQuantity(productId: string | number, quantity: number) {
    const item = items.value.find(item => item.product.id === productId)
    if (item) {
      if (quantity <= 0) {
        removeFromCart(productId)
      } else {
        item.quantity = quantity
        persistCart()
      }
    }
  }

  function incrementQuantity(productId: string | number) {
    const item = items.value.find(item => item.product.id === productId)
    if (item) {
      item.quantity++
      persistCart()
    }
  }

  function decrementQuantity(productId: string | number) {
    const item = items.value.find(item => item.product.id === productId)
    if (item) {
      if (item.quantity > 1) {
        item.quantity--
        persistCart()
      } else {
        removeFromCart(productId)
      }
    }
  }

  function clearCart() {
    items.value = []
    persistCart()
    removePromo()
  }

  function isInCart(productId: string | number): boolean {
    return items.value.some(item => item.product.id === productId)
  }

  function getItemQuantity(productId: string | number): number {
    const item = items.value.find(item => item.product.id === productId)
    return item?.quantity || 0
  }

  if (typeof window !== 'undefined') {
    const storedCode = loadStoredPromoCode()
    if (storedCode) {
      applyPromoCode(storedCode, { silent: true }).catch(() => {
        removePromo()
      })
    }
  }

  watch(
    totalPrice,
    (newTotal, oldTotal) => {
      if (!appliedPromo.value) return
      if (newTotal <= 0) {
        removePromo()
        return
      }
      if (newTotal === oldTotal) return
      if (isApplyingPromo.value) return
      refreshPromo({ silent: true }).catch(() => {
        removePromo()
      })
    },
    { flush: 'post' }
  )

  return {
    items,
    appliedPromo,
    isApplyingPromo,
    itemsCount,
    totalPrice,
    discountAmount,
    totalAfterDiscount,
    hasPromo,
    isEmpty,
    addToCart,
    removeFromCart,
    updateQuantity,
    incrementQuantity,
    decrementQuantity,
    clearCart,
    isInCart,
    getItemQuantity,
    applyPromoCode,
    refreshPromo,
    redeemPromo,
    removePromo
  }
})
