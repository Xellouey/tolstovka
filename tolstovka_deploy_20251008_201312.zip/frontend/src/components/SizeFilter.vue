<template>
  <div v-if="sizes.length" class="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
    <button
      class="px-3 py-1.5 rounded-full border text-xs font-semibold uppercase tracking-wide transition-colors duration-200"
      :class="activeSize ? 'border-gray-300 text-gray-500 hover:border-gray-400' : 'bg-brand-primary text-brand-dark border-brand-primary shadow-sm'"
      :disabled="disabled"
      type="button"
      @click="selectSize(null)"
    >
      Все
    </button>
    <button
      v-for="size in sizes"
      :key="size"
      class="px-3 py-1.5 rounded-full border text-xs font-semibold uppercase tracking-wide transition-all duration-200"
      :class="size === activeSize ? 'bg-brand-primary text-brand-dark border-brand-primary shadow-sm' : 'border-gray-300 text-gray-600 hover:border-brand-primary hover:text-brand-dark'"
      :disabled="disabled"
      type="button"
      @click="selectSize(size)"
    >
      {{ size }}
    </button>
  </div>
</template>

<script setup lang="ts">
interface Props {
  sizes: string[]
  activeSize?: string | null
  disabled?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  sizes: () => [],
  activeSize: null,
  disabled: false
})

const emit = defineEmits<{
  (e: 'change', size: string | null): void
}>()

function selectSize(size: string | null) {
  if (props.disabled) return
  emit('change', size)
}
</script>
